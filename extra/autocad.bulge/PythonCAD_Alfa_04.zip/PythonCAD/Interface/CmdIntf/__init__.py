#
# Copyright (c) 2010, PythonCad team
#
# Cui = custom user interface
# The custom user interface defines menu's, toolbars and palettes
# which are used to interact with the user.


