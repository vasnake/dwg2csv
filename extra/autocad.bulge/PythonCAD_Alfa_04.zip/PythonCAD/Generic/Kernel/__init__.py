#
# Copyright (c) 2004 Art Haas
#

#
# this file is needed for Python's import mechanism
#

